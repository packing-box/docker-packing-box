   PELock is a software security solution designed for protection of
   any 32 bit Windows applications against cracking, tampering and
   reverse engineering analysis.

   PELock features:

 * PELock comes with a built-in licensing system, you can use it
   to easily add license key system for your application. You can
   also set various time-trial limitations for the protected
   application, e.g. 30 days trial.

 * You can closely integrate the protection and licensing features
   using dedicated SDK with hundreds of examples for C/C++, Delphi,
   Lazarus, Freepascal, PureBasic, PowerBASIC, D, Assembler with
   full source codes.

 * You can protect any compiled application file for Windows as
   long as it's compatible with Portable Executable format, no
   matter what programming language or development environment was
   used to create it.

 * PELock has a built-in binder for additional application DLL
   libraries, it's possible to merge your main application EXE file
   with any number of extra DLL libraries into single output EXE file.