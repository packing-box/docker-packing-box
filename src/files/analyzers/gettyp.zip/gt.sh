#!/bin/bash
PWD=`pwd`
if [[ "$1" = /* ]]; then TARGET="$1"; else TARGET="$PWD/$1"; fi
cd "/home/user/.opt/analyzers/gettyp"
WINEPREFIX="$HOME/.wine32" WINEARCH=win32 wine "gtw.exe" "${TARGET//\//\\}"
cd "$PWD"
