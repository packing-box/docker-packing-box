#!/bin/bash
PWD=`pwd`
if [[ "$1" = /* ]]; then TARGET="$1"; else TARGET="$PWD/$1"; fi
cd "/opt/detectors/gettyp"
wine "gtw.exe" "${TARGET//\//\\}"
cd "$PWD"
